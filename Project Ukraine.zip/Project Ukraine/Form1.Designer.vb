﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class project_ukraine
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.textbox1 = New System.Windows.Forms.RichTextBox()
        Me.go = New System.Windows.Forms.Button()
        Me.forward = New System.Windows.Forms.Button()
        Me.backwards = New System.Windows.Forms.Button()
        Me.favourites = New System.Windows.Forms.Button()
        Me.history = New System.Windows.Forms.Button()
        Me.newtab = New System.Windows.Forms.Button()
        Me.close = New System.Windows.Forms.Button()
        Me.refresh = New System.Windows.Forms.Button()
        Me.Home = New System.Windows.Forms.Button()
        Me.WebBrowser = New System.Windows.Forms.WebBrowser()
        Me.SuspendLayout()
        '
        'textbox1
        '
        Me.textbox1.BackColor = System.Drawing.SystemColors.Info
        Me.textbox1.Font = New System.Drawing.Font("Arial", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.textbox1.Location = New System.Drawing.Point(12, 12)
        Me.textbox1.Name = "textbox1"
        Me.textbox1.Size = New System.Drawing.Size(302, 104)
        Me.textbox1.TabIndex = 1
        Me.textbox1.Text = ""
        '
        'go
        '
        Me.go.Location = New System.Drawing.Point(320, 41)
        Me.go.Name = "go"
        Me.go.Size = New System.Drawing.Size(91, 75)
        Me.go.TabIndex = 2
        Me.go.Text = "GO!"
        Me.go.UseVisualStyleBackColor = True
        '
        'forward
        '
        Me.forward.Location = New System.Drawing.Point(417, 41)
        Me.forward.Name = "forward"
        Me.forward.Size = New System.Drawing.Size(91, 75)
        Me.forward.TabIndex = 4
        Me.forward.Text = "Forward"
        Me.forward.UseVisualStyleBackColor = True
        '
        'backwards
        '
        Me.backwards.Location = New System.Drawing.Point(514, 41)
        Me.backwards.Name = "backwards"
        Me.backwards.Size = New System.Drawing.Size(91, 75)
        Me.backwards.TabIndex = 5
        Me.backwards.Text = "Back"
        Me.backwards.UseVisualStyleBackColor = True
        '
        'favourites
        '
        Me.favourites.Location = New System.Drawing.Point(611, 41)
        Me.favourites.Name = "favourites"
        Me.favourites.Size = New System.Drawing.Size(91, 75)
        Me.favourites.TabIndex = 6
        Me.favourites.Text = "Favourites"
        Me.favourites.UseVisualStyleBackColor = True
        '
        'history
        '
        Me.history.Location = New System.Drawing.Point(708, 41)
        Me.history.Name = "history"
        Me.history.Size = New System.Drawing.Size(91, 75)
        Me.history.TabIndex = 7
        Me.history.Text = "History"
        Me.history.UseVisualStyleBackColor = True
        '
        'newtab
        '
        Me.newtab.Location = New System.Drawing.Point(805, 41)
        Me.newtab.Name = "newtab"
        Me.newtab.Size = New System.Drawing.Size(91, 75)
        Me.newtab.TabIndex = 8
        Me.newtab.Text = "New Tab"
        Me.newtab.UseVisualStyleBackColor = True
        '
        'close
        '
        Me.close.Location = New System.Drawing.Point(999, 41)
        Me.close.Name = "close"
        Me.close.Size = New System.Drawing.Size(91, 75)
        Me.close.TabIndex = 9
        Me.close.Text = "Exit"
        Me.close.UseVisualStyleBackColor = True
        '
        'refresh
        '
        Me.refresh.Location = New System.Drawing.Point(902, 41)
        Me.refresh.Name = "refresh"
        Me.refresh.Size = New System.Drawing.Size(91, 75)
        Me.refresh.TabIndex = 10
        Me.refresh.Text = "Refresh"
        Me.refresh.UseVisualStyleBackColor = True
        '
        'Home
        '
        Me.Home.Location = New System.Drawing.Point(384, 8)
        Me.Home.Name = "Home"
        Me.Home.Size = New System.Drawing.Size(668, 27)
        Me.Home.TabIndex = 11
        Me.Home.Text = "Home"
        Me.Home.UseVisualStyleBackColor = True
        '
        'WebBrowser
        '
        Me.WebBrowser.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.WebBrowser.Location = New System.Drawing.Point(19, 132)
        Me.WebBrowser.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser.Name = "WebBrowser"
        Me.WebBrowser.Size = New System.Drawing.Size(1120, 478)
        Me.WebBrowser.TabIndex = 12
        '
        'project_ukraine
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(1154, 622)
        Me.Controls.Add(Me.WebBrowser)
        Me.Controls.Add(Me.Home)
        Me.Controls.Add(Me.refresh)
        Me.Controls.Add(Me.close)
        Me.Controls.Add(Me.newtab)
        Me.Controls.Add(Me.history)
        Me.Controls.Add(Me.favourites)
        Me.Controls.Add(Me.backwards)
        Me.Controls.Add(Me.forward)
        Me.Controls.Add(Me.go)
        Me.Controls.Add(Me.textbox1)
        Me.Name = "project_ukraine"
        Me.Text = "project_ukraine"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents textbox1 As RichTextBox
    Friend WithEvents go As Button
    Friend WithEvents forward As Button
    Friend WithEvents backwards As Button
    Friend WithEvents favourites As Button
    Friend WithEvents history As Button
    Friend WithEvents newtab As Button
    Friend WithEvents close As Button
    Friend WithEvents refresh As Button
    Friend WithEvents Home As Button
    Friend WithEvents WebBrowser As WebBrowser
End Class
