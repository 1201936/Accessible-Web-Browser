﻿Public Class project_ukraine
    Private Sub project_ukraine_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.Text = "Web Browser" 'core code for web browser'


    End Sub

    Private Sub go_Click(sender As Object, e As EventArgs) Handles go.Click

        WebBrowser.Navigate(textbox1.Text) 'navigate to webpage from textbox1'

    End Sub

    Private Sub WebBrowser_Navigating(sender As Object, e As WebBrowserNavigatingEventArgs)


    End Sub

    Private Sub backwards_Click(sender As Object, e As EventArgs) Handles backwards.Click


        WebBrowser.GoBack() 'back button'

    End Sub

    Private Sub close_Click(sender As Object, e As EventArgs) Handles close.Click




    End Sub

    Private Sub forward_Click(sender As Object, e As EventArgs) Handles forward.Click

        WebBrowser.GoForward()



    End Sub

    Private Sub Home_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Home.Click

        WebBrowser.Url = New System.Uri("http://www.bbc.co.uk") 'navigate home button to BBC website'


    End Sub


    Private Sub WebBrowser_DocumentCompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs) Handles WebBrowser.DocumentCompleted




    End Sub
End Class
